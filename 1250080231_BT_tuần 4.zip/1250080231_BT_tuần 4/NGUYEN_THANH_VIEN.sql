create table phongban (
    maphong int primary key,
    tenphong varchar2(50),
    truongphong int,
    ngaynhanchuc date
);

create table nhanvien (
    manv int primary key,
    honv varchar2(50),
    tennv varchar2(50),
    ngaysinh date,
    diachi varchar2(50),
    phai varchar2(10),
    luong int,
    manql int,
    phong int,
    constraint fk_nv_phong foreign key (phong) references phongban(maphong)
);


create table diadiemphong (
   maphong int primary key,
   diadiem varchar2(50),
   constraint fk_ddp_phong foreign key (maphong) references phongban(maphong)
)

create table dean (
    mada int primary key,
    tenda varchar2(50),
    ddiemda varchar2(50),
    phong int,
    constraint fk_da_phong foreign key (phong)
        references phongban(maphong)
);
create table phancong (
    manv int,
    mada int,
    thoigian int,
    primary key (manv, mada),
    constraint fk_pc_nv foreign key (manv) references nhanvien(manv),
    constraint fk_pc_da foreign key (mada) references dean(mada)
);

create table thannhan (
    matn int primary key,
    hotn varchar2(50),
    tentn varchar2(50),
    phai varchar2(10),
    ngaysinh date
);

create table nvien_tnhan (
    manv int,
    matn int,
    quanhe varchar2(50),
    primary key (manv, matn),
    constraint fk_nvt_nv foreign key (manv) references nhanvien(manv),
    constraint fk_nvt_tn foreign key (matn) references thannhan(matn)
);


insert into phongban values (1,'Hành Chính',1,date '2026-01-01');
insert into phongban values (2,'Tài Vụ',2,date '2015-05-10');

insert into nhanvien values
(1,'Pham','Huynh',date '1995-06-30','hn','nam',8000000,1,1);

insert into nhanvien values
(2,'Nguyen','An',date '1990-03-10','hcm','nam',9000000,1,1);

insert into nhanvien values
(3,'Tran','Lan',date '1998-06-06','dn','nu',7000000,2,2);

insert into dean values (1,'da01','hn',1);
insert into dean values (2,'da02','hcm',2);

insert into phancong values (1,1,35);
insert into phancong values (2,1,20);
insert into phancong values (3,2,40);

insert into thannhan values
(1,'Pham','Huy','nam',date '2000-06-30');

insert into nvien_tnhan values (1,1,'anh em');


/*1*/
select * from nhanvien
where tennv = 'Huynh';


/*2*/
select manv, honv, tennv, diachi
from nhanvien
inner join phongban
on nhanvien.phong = phongban.maphong
where tenphong = 'Hành Chính';

/*3*/
select manv, honv, tennv, diachi
from nhanvien
inner join phongban
on nhanvien.phong = phongban.maphong
where tenphong in ('Hành Chính', 'Tài Vụ');

/*4*/
select nv.manv, nv.honv, nv.tennv
from nhanvien nv
inner join phancong pc
on nv.manv = pc.manv
inner join dean da
on pc.mada = da.mada;

/*5*/
select da.mada, da.tenda, pb.tenphong, nv.manv as matruongphong, nv.honv as hotruongphong, nv.tennv as tentruongphong
from dean da
inner join phongban pb 
on da.phong = pb.maphong
inner join nhanvien nv
on pb.truongphong = nv.manv;

/*6*/
select nv.manv, nv.honv, nv.tennv
from nhanvien nv
inner join phancong pc
on nv.manv = pc.manv
inner join dean da
on pc.mada = da.mada
where da.mada = to_number(substr('DA01', 3)) and pc.thoigian > 30;

/*7*/
select distinct nv.manv, nv.honv, nv.tennv
from nhanvien nv
inner join nvien_tnhan nt 
on nv.manv = nt.manv
inner join thannhan tn 
on nt.matn = tn.matn
where nv.tennv = tn.tentn;





/*9*/
select nv.manv, nv.honv, nv.tennv
from nhanvien nv
inner join nhanvien ql
on nv.manql = ql.manv
where ql.honv in ('Pham', 'Huynh');

/*10*/
select nv.manv, nv.honv, nv.tennv
from nhanvien nv
inner join phancong pc
on nv.manv = pc.manv
group by nv.manv, nv.honv, nv.tennv
having count(distinct pc.mada) = (
select count(*)
from dean
);

/*11*/
select nv.manv, nv.honv, nv.tennv
from nhanvien nv
where nv.manv not in (
select pc.manv
from phancong pc
);

/*12*/
select avg(luong) as luongtrungbinh
from nhanvien

/*13*/
select avg(luong) as luongtb_nam
from nhanvien
where nhanvien.phai = 'nam';

/*14*/
select count(*) as tong_de_an
from dean da;

/*15*/
select da.mada, da.tenda, count(pc.manv) as so_nhan_vien
from dean da
inner join phancong pc
on da.mada = pc.mada
group by da.mada, da.tenda;\

/*16*/
select da.mada, da.tenda, count(nv.manv) as so_nv_nu
from dean da
inner join phancong pc
on da.mada = pc.mada
inner join nhanvien nv
on pc.manv = nv.manv
where nv.phai = 'nu'
group by da.mada, da.tenda;

/*17*/
update phancong pc
set pc.thoigian = pc.thoigian + 4
where pc.manv in (
select nv.manv
from nhanvien nv
where nv.phai = 'nam'
);
 /*18*/
delete from phancong
where manv in (
select manv
from nhanvien
where luong < 500000
);
delete from nhanvien
where luong < 500000;



