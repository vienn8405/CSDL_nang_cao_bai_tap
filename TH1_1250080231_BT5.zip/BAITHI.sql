create table tuyen (
    matuyen   varchar2(10) primary key,
    bendau    varchar2(10),
    bencui    varchar2(10),
    giatuyen  number,
    ngxb      date,
    tgdk      number
);

create table xe (
    maxe     varchar2(10) primary key,
    bienks   varchar2(15),
    matuyen  varchar2(10),
    soghet1  number,
    soghet2  number,
    constraint fk_xe_tuyen foreign key (matuyen)
        references tuyen(matuyen)
);


create table khach (
    mahk     varchar2(10) primary key,
    hoten    varchar2(50),
    gioitinh varchar2(5),
    cmnd     varchar2(20)
);

create table vexe (
    matuyen  varchar2(10),
    mahk     varchar2(10),
    ngmua    date,
    giave    number,
    constraint pk_vexe primary key (matuyen, mahk, ngmua),
    constraint fk_vexe_tuyen foreign key (matuyen)
        references tuyen(matuyen),
    constraint fk_vexe_khach foreign key (mahk)
        references khach(mahk)
);

insert into tuyen values ('t11a','sg','dl',210000,date '2016-12-26',6);
insert into tuyen values ('t32d','pt','sg',120000,date '2016-12-30',4);
insert into tuyen values ('t06f','nt','dng',225000,date '2017-01-02',7);

insert into xe values ('x01','52ld-4393','t11a',20,20);
insert into xe values ('x02','59ld-7247','t32d',36,36);
insert into xe values ('x03','55ld-6850','t06f',15,15);

insert into khach values ('kh01','lâm văn bền','nam','655615896');
insert into khach values ('kh02','dương thị lục','nữ','275648642');
insert into khach values ('kh03','hoàng thanh tùng','nam','456889143');

insert into vexe values ('t11a','kh01',date '2016-12-20',210000);
insert into vexe values ('t32d','kh02',date '2016-12-25',144000);
insert into vexe values ('t06f','kh03',date '2016-12-30',270000);


--3
alter table tuyen
add constraint ck_tuyen_tgdk_gia
check (tgdk <= 5 or giatuyen > 200000);
--4
create or replace trigger trg_tang_gia
before insert or update on tuyen
for each row
begin
    if :new.ngxb between date '2016-12-29' and date '2017-01-05' then
        :new.giatuyen := :new.giatuyen * 1.2;
    end if;
end;
/
--5
select *
from vexe
where extract(month from ngmua) = 12
order by giave desc;
--6
select matuyen
from vexe
where extract(year from ngmua) = 2016
group by matuyen
having count(*) = (
    select min(count(*))
    from vexe
    where extract(year from ngmua) = 2016
    group by matuyen
);
--7
select v.matuyen
from vexe v
join khach k on v.mahk = k.mahk
group by v.matuyen
having count(distinct k.gioitinh) = 2;
--8
select k.mahk, k.hoten
from khach k
where k.gioitinh = 'nữ'
and not exists (
    select *
    from tuyen t
    where not exists (
        select *
        from vexe v
        where v.matuyen = t.matuyen
        and v.mahk = k.mahk
    )
);




