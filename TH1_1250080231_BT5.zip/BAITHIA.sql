CREATE TABLE app_user (
    user_id      VARCHAR2(10) PRIMARY KEY,
    user_name    VARCHAR2(50),
    password_    VARCHAR2(50),
    regday       DATE DEFAULT SYSDATE,
    nationality  VARCHAR2(30)
);


create table channel (
    channelid  varchar2(10) primary key,
    cname      varchar2(50),
    subscribes number,
    owner_id   varchar2(10),
    created    date,
    constraint fk_channel_user
        foreign key (owner_id)
        references app_user(user_id)
);

create table video (
    videoid   varchar2(10) primary key,
    title     varchar2(100),
    duration  number,
    age       number
);
select table_name from user_tables;

create table share_n (
    videoid   varchar2(10),
    channelid varchar2(10),
    constraint pk_share primary key (videoid, channelid),
    constraint fk_share_video
        foreign key (videoid) references video(videoid),
    constraint fk_share_channel
        foreign key (channelid) references channel(channelid)
);

insert into app_user values ('001', 'faptv',      '123456abc', date '2014-01-01', 'Viet Nam');
insert into app_user values ('002', 'kemxoiv',    '@147869iii', date '2015-06-05', 'Campuchia');
insert into app_user values ('003', 'openshare',  'qwertyuiop', date '2009-05-12', 'Viet Nam');

insert into channel values ('C120', 'FAP TV',         2343, '001', date '2014-01-02');
insert into channel values ('C905', 'Kem xoi TV',     1032, '002', date '2015-07-09');
insert into channel values ('C357', 'OpenShare Cafe', 5064, '003', date '2010-12-10');

insert into video values ('V100229', 'FAPtv Com Nguoi Tap 41 - Dot Nhap', 469, 18);
insert into video values ('V211002', 'Kem xoi Tap 31 - May Kool tinh yeu cua anh', 312, 16);
insert into video values ('V400002', 'Noi tinh yeu ket thuc - Hoang Tuan', 378, 0);

insert into share_n values ('V100229', 'C905');
insert into share_n values ('V211002', 'C120');
insert into share_n values ('V400002', 'C357');
 
 
--3
regday date default sysdate

--4
create or replace trigger trg_channel_date
before insert or update on channel
for each row
declare
    v_regday date;
begin
    select regday
    into v_regday
    from app_user
    where user_id = :new.owner_id;

    if :new.created < v_regday then
        raise_application_error(-20001, 'Ngay tao kenh phai >= ngay dang ky user');
    end if;
end;
/

--5
select *
from video
where age >= 16;
--6
select *
from channel
where subscribes = (
    select max(subscribes) from channel
);

--7
select v.videoid,
       v.title,
       count(s.channelid) as so_kenh_chia_se
from video v
left join share_n s on v.videoid = s.videoid
where v.age = 18
group by v.videoid, v.title;
--8
select v.videoid, v.title
from video v
where not exists (
    select *
    from channel c
    where not exists (
        select *
        from share_n s
        where s.videoid = v.videoid
          and s.channelid = c.channelid
    )
);
